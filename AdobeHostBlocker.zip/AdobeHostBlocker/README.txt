Unzip & Run as administrator
This edits the host file and blocks Adobe Genuine Service addresses from a.dove.isdumb.one